document.addEventListener('DOMContentLoaded', function() {
    const mathButton = document.getElementById('math-btn');
    const programmingButton = document.getElementById('programming-btn');
    const englishButton = document.getElementById('english-btn');
    const challengeTitle = document.getElementById('challenge-title');
    const answerInput = document.getElementById('answer');
    const submitButton = document.querySelector('.submit-btn');

    // Initialize challenge points
    let challengePoints = parseInt(localStorage.getItem('challengePoints')) || 3;

    // Store a question set for each subject
    const questions = {
        Mathematics: [
            { question: 'What is 1 + 1?', answer: '2' },
            { question: 'What is 3 * 3?', answer: '9' },
            { question: 'What is 12 - 4?', answer: '8' },
            { question: 'What is 5 + 7?', answer: '12' }
        ],
        Programming: [
            { question: 'What will be the output? print("Hello World!")', answer: 'Hello World!' },
            { question: 'What is the keyword used to define a function in Python?', answer: 'def' },
            { question: 'What does HTML stand for?', answer: 'HyperText Markup Language' },
            { question: 'What is the output of 2 ** 3 in Python?', answer: '8' }
        ],
        English: [
            { question: 'What is your name?', answer: 'Your Name' }, // Adjust as needed
            { question: 'What is the opposite of "hot"?', answer: 'cold' },
            { question: 'What is the past tense of "go"?', answer: 'went' },
            { question: 'What is the synonym of "happy"?', answer: 'joyful' }
        ]
    };

    // Function to get a random question from a selected category
    function getRandomQuestion(subject) {
        const subjectQuestions = questions[subject];
        const randomIndex = Math.floor(Math.random() * subjectQuestions.length);
        return subjectQuestions[randomIndex];
    }

    // Function to start the challenge based on the selected category
    function startChallenge(subject) {
        const selectedQuestion = getRandomQuestion(subject);
        challengeTitle.textContent = selectedQuestion.question;
        answerInput.value = ''; // Clear the input
        answerInput.focus(); // Focus on input for user convenience
        answerInput.dataset.correctAnswer = selectedQuestion.answer; // Store the correct answer in the input element
    }

    mathButton.addEventListener('click', function() {
        startChallenge('Mathematics');
    });

    programmingButton.addEventListener('click', function() {
        startChallenge('Programming');
    });

    englishButton.addEventListener('click', function() {
        startChallenge('English');
    });

    submitButton.addEventListener('click', function() {
        const correctAnswer = answerInput.dataset.correctAnswer; // Retrieve the correct answer
        if (answerInput.value.trim() === correctAnswer) {
            challengePoints += 1; // Increment points for correct answer
            localStorage.setItem('challengePoints', challengePoints); // Save to local storage
            alert(`Correct! Your points: ${challengePoints}`);
            // Optionally, reset challenge
            answerInput.value = '';
            challengeTitle.textContent = 'Select a category to start!';
        } else {
            alert('Incorrect answer. Try again!');
        }
    });
});
