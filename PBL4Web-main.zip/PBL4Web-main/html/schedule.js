document.addEventListener("DOMContentLoaded", () => {
    const dropdownButtons = document.querySelectorAll(".dropdown-btn");

    dropdownButtons.forEach(button => {
        button.addEventListener("click", () => {
            const extraInfo = button.previousElementSibling.querySelector(".extra-info");
            extraInfo.classList.toggle("hidden");

            // Toggle button arrow direction
            button.textContent = extraInfo.classList.contains("hidden") ? "‹" : "›";
        });
    });
});
